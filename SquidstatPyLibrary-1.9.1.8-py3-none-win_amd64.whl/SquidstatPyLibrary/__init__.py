import sys
import os
import ctypes

# Get the directory of the current file
current_directory = os.path.dirname(os.path.abspath(__file__))

# Load all the DLL files
dll_files = [
    os.path.join(current_directory, "Qt6Core.dll"),
    os.path.join(current_directory, "Qt6Gui.dll"),
    os.path.join(current_directory, "Qt6SerialPort.dll"),
    os.path.join(current_directory, "Qt6Widgets.dll"),
    os.path.join(current_directory, "SquidstatLibrary.dll")
]

for dll_file in dll_files:
    ctypes.CDLL(dll_file)


# Check if PySide6 is installed and import the QApplication
try:
    from PySide6.QtWidgets import QApplication
except ImportError:
    print("PySide6 is not installed. Please install PySide6. or do from PySide6.QtWidgets import QApplication manually")

# Get the Python version
python_version = f"{sys.version_info.major}.{sys.version_info.minor}"

# Determine the subdirectory based on the Python version
if python_version == '3.10':
    from .py310 import *

if python_version == '3.8':
    from .py38 import *
if python_version == '3.7':
    from .py37 import *
if python_version == '3.9':
    from .py39 import *
if python_version == '3.11':
    from .py311 import *
if python_version == '3.12':
    from .py312 import *
if python_version == '3.13':
    from .py313 import *
if python_version == '3.14':
    from .py314 import *