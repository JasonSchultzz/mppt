import sys

# Get the Python version
python_version = f"{sys.version_info.major}.{sys.version_info.minor}"

# Determine the subdirectory based on the Python version
if python_version == '3.14':
    from .SquidstatPyLibrary import *
   