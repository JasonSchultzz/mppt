import sys
import os
import ctypes


# Check if PySide2 is installed and then print the warning.
try:
    from PySide2.QtWidgets import QApplication
    print("Warning: PySide2 is installed, but this application is designed for PySide6. Ensure PySide6 is used for compatibility.")
except ImportError:
    pass

# Get the directory of the current file
current_directory = os.path.dirname(os.path.abspath(__file__))

# Load all the DLL files
dll_files = [
    os.path.join(current_directory, "Qt6Core.dll"),
    os.path.join(current_directory, "Qt6Gui.dll"),
    os.path.join(current_directory, "Qt6SerialPort.dll"),
    os.path.join(current_directory, "Qt6Widgets.dll"),
    os.path.join(current_directory, "SquidstatLibrary.dll")
]

for dll_file in dll_files:
    ctypes.CDLL(dll_file)



# Check if PySide6 is installed and import the QApplication
try:
    from PySide6.QtWidgets import QApplication
except ImportError:
    print("Error: PySide6 is not installed. Please install PySide6 or manually import QApplication using 'from PySide6.QtWidgets import QApplication")
    sys.exit(1)

# Get the Python version
python_version = f"{sys.version_info.major}.{sys.version_info.minor}"

# Determine the subdirectory based on the Python version
if python_version == '3.10':
    from .py310 import *

if python_version == '3.8':
    from .py38 import *
if python_version == '3.7':
    from .py37 import *
if python_version == '3.9':
    from .py39 import *
if python_version == '3.11':
    from .py311 import *
if python_version == '3.12':
    from .py312 import *
if python_version == '3.13':
    from .py313 import *
if python_version == '3.14':
    from .py314 import *